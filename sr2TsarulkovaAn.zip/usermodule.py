log_true = 1
log_false = 0
divider = '-'
captionTab = "| A | B | C | -C | A&B | B&C | -C -> A |A&B <=> B&C | (A&B <=> B&C) + (-C -> A) |"
lines =  len(captionTab) * divider
print(lines)
print(captionTab)
A = log_false
B = log_false
C = log_false
result = "| " + str(A) + " | "+ str(B) + " | " + str(C) +" | "+ str(int(not C)) +"  |  "+ str(A and B) +"  |  "+ str(B and C) +"  |    " + str(not not C or A) +"    |     "+ str(A and B == B and C) +"      |             "+ str((A and B == B and C) or (not not C or A)) +"             | "
print(result)
A = log_false
B = log_false
C = log_true
print(result)
A = log_false
B = log_false
C = log_false