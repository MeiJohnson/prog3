"""
Царулкова Анастасия Витальевна
2 группа 3 подгруппа

Copyright: 09.2019

Этот скрипт вычисляет выводит на экран таблицу истинности выражение №11 из СР2
"""

divider = '-'
captionTab = "| A | B | C | ¬C | A ˄ B | B ˄ C | ¬C → A |A&B ↔ B&C | (A&B ↔ B&C) ˅ (¬C -> A) |"
lines =  len(captionTab) * divider
print(lines)
print(captionTab)
print(lines)
A = [0,0,0,0,1,1,1,1]
B = [0,0,1,1,0,0,1,1]
C = [0,1,0,1,0,1,0,1]

for lineNum in range(len(A)):
  result = "| " + str(int(bool(A[lineNum]))) + " | "+ str(int(bool(B[lineNum]))) + " | " + str(int(bool(C[lineNum])))
  result2 = " | "+ str(int(not C[lineNum])) +"  |   "+ str(A[lineNum] and B[lineNum]) +"   |   "+ str(int(bool(B[lineNum]) and bool(C[lineNum])))
  result3 = "   |   " + str(int(bool(not not C[lineNum])) or int(bool(A[lineNum]))) +"    |     "+ str(A[lineNum] and B[lineNum] == B[lineNum] and C[lineNum]) +"    |            "
  result4 = str(int(bool(A[lineNum] and B[lineNum]) == bool(B[lineNum] and C[lineNum]) or bool((not not C[lineNum] or A[lineNum])))) +"            | "
  print(result+result2+result3+result4)
  print(lines)



